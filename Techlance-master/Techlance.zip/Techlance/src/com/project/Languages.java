package com.project;

public class Languages {
	String[] name;
	
	public Languages(String[] lang) {
		name = lang;
		
	}

}
